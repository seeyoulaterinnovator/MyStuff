export const EMPTY = 0;
export const AGENT_TYPING = 1;
export const SESSION_START = 2;
export const SESSION_STOP = 3;
export const CUSTOM = 10;
