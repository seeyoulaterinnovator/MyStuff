import App from './App.svelte';

export default class ErChat {
  constructor(parameters) {
    this.parameters = parameters;
  }

  attach(element) {
    this.app = new App({
      target: element,
      props: {
        chatParameters: this.parameters
      }
    });
  }

  connect() {
    this.app.connect()
  }
}
