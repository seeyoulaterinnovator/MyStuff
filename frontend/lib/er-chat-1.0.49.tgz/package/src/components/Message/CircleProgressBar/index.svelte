<svg viewBox="0 0 30 30" width={w} height={h}>
  <circle cx="15" cy="15" r="13" stroke="#FFFFFF" stroke-opacity="0.4" stroke-width="2" fill="none" />
  <path fill="none" stroke="#FFDD00" stroke-width="2" d={d} />
</svg>

<script>
import {onMount} from 'svelte';

function polarToCartesian(centerX, centerY, radius, angleInDegrees) {
  const angleInRadians = (angleInDegrees-90) * Math.PI / 180.0;

  return {
    x: centerX + (radius * Math.cos(angleInRadians)),
    y: centerY + (radius * Math.sin(angleInRadians))
  };
}

function describeArc(x, y, radius, startAngle, endAngle){

    const start = polarToCartesian(x, y, radius, endAngle);
    const end = polarToCartesian(x, y, radius, startAngle);

    var largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";

    const d = [
        "M", start.x, start.y,
        "A", radius, radius, 0, largeArcFlag, 0, end.x, end.y
    ].join(" ");

    return d;
}

let d
export let progress = 0
export let w = 30
export let h = 30

function setProgress(percent) {
  d = describeArc(15, 15, 13, 0, 3.6 * percent)
}

$: if (progress >= 0 && progress <= 100) {
  setProgress(progress)
}


onMount(() => {
  d = describeArc(15, 15, 13, 0, 0)
})
</script>

<style>


</style>
