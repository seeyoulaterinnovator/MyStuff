<div
  class="chat-message"
  class:chat-message--error={message.isError}
  class:chat-message--attachment={message.attachment || message.type === 'PushUrl'}
  class:chat-message--user={message.isClient}
  class:chat-message--minimal={message.utcTime}
>
  {#if message.isClient === false && message.from !== "" && showFrom }
  <div class="chat-message__from">
    { message.from }
  </div>
  {/if}

  <div class="chat-message__wrap">
    <div class="chat-message__body">
      {#if message.text !== "" && message.text !== undefined && message.type !== 'PushUrl'}
      <div class="chat-message__content">
        {@html validContent()}
      </div>
      {/if}

      {#if message.attachment}
      <div class="chat-message__attachment">
        {#if message.attachment.preview !== undefined}
          <div class="chat-message__preview">
            <div class="chat-message__preview-img" style={style}> </div>
              {#if message.attachment.percent !== undefined && message.attachment.percent !== 100}
                <div class="chat-message__preview-img-shadow"> </div>
                <div class="chat-message__circle-bar">
                  <CircleProgressBar progress={message.attachment.percent}/>
                </div>
              {/if}
          </div>
        {:else}
          {#if message.attachment.percent !== undefined && message.attachment.percent !== 100}
            <div class="chat-message__circle-bar-without-preview">
              <CircleProgressBar progress={message.attachment.percent}/>
            </div>
          {:else}
          <span class="chat-message__attachmentIcon">
            {#if isDownloadFile}
              <div class="chat-message__circle-bar-download">
                <CircleProgressBar progress={downloadedPercent} w="19" h="19"/>
              </div>
            {:else}
              <IconSmallHusks />
            {/if}
          </span>
          {/if}
        {/if}

        <div class="chat-message__attachmentContent">
          <button
            class="chat-message__attachmentName"
            on:click|preventDefault={onFileNameClick}
          >
            <span>
              { message.attachment.fileName }
            </span>
          </button>

          <div class="chat-message__attachmentSize">
            { formatFileSize(message.attachment.fileSize) }
          </div>

          {#if message.attachment.error !== undefined}
          <div class="chat-message__attachmentError">
            { message.attachment.error }
          </div>
          {/if}
        </div>
      </div>
      {/if}

    {#if message.type === 'PushUrl'}
      <div class="chat-message__attachment">
        <span class="chat-message__attachmentIcon">
          <IconSmallHusks />
        </span>

        <div class="chat-message__attachmentContent">
          <button
            class="chat-message__attachmentName"
            on:click|preventDefault={downloadFileByLink}
          >
            <div>
              { getPushFileName() }
            </div>
          </button>
        </div>
      </div>
      {/if}

      <div class="chat-message__body-corner"></div>
    </div><!-- chat-message__body -->

    {#if message.utcTime && showTime}
    <div class="chat-message__info">
      <div
        class="chat-message__status"
        class:chat-message__status--loaded={!message.isLoaded}
        class:chat-message__status--is-read={message.isReaded}
      >
        <IconOk />

        <IconDoubleOk />
      </div>

      <div class="chat-message__time">
        { getMessageTime() }
      </div>
    </div>
    {/if}
  </div>
</div>

<script>
import { createEventDispatcher, onMount} from 'svelte';
import CircleProgressBar from './CircleProgressBar/index.svelte';
import IconOk from 'components/icons/ok.svelte';
import IconDoubleOk from 'components/icons/double_ok.svelte';
import IconSmallHusks from 'components/icons/small_husks.svelte';
import { escapeMessageText, formatFileSize } from '../../helpers';

const dispatch = createEventDispatcher();
const STATUS_MESSAGE_SENDING = 0;
const STATUS_MESSAGE_SEND = 1;
const STATUS_MESSAGE_READED = 2;

/* vars */
let bufferStatus = STATUS_MESSAGE_SENDING;
let style = ''
$: if (message.attachment) {
  style = `background-image: url('${message.attachment.preview}')`
  }
let downloadStatus = false
let downloadedData
let downloadedPercent
let isDownloadFile = false
$: if (message.attachment) {
  downloadedPercent = downloadedData / message.attachment.fileSize * 100
  }

$: updateBufferStatus(isAgentTyping)

/* props */
export let message = {
  status: STATUS_MESSAGE_SEND,
  isClient: false,
  utcTime: null,
  from: null,
  attachment: {
    preview: null
  }
};
export let showTime = true;
export let showFrom = true;
export let isAgentTyping = false;
export let chat

function updateBufferStatus(isAgentTyping) {
  if (isAgentTyping === true && bufferStatus === STATUS_MESSAGE_SEND) {
    bufferStatus = STATUS_MESSAGE_READED
  }
}

function getStatusClass() {
  if ( message.bufferStatus > 0 ) {
    return 'chat-message__status--loaded'
  } else if ( message.bufferStatus > 1 ) {
    return 'chat-message-component__status--is-read'
  }
}

function getMessageDatetime() {
  let datetime = new Date(message.utcTime);

  return datetime
}

function getPushFileName() {
  if (message.type === 'PushUrl') {
    const url  = new URL(message.text)
    const fileName = url.searchParams.get('fileName')
    if (fileName) {
      return decodeURI(fileName)
    }
  }
  return 'Файл'
}

function getMessageTime() {
  const datetime = getMessageDatetime();
  const hours = datetime.getHours();
  const minutes = getMessageDatetime().getMinutes();
  const zeroMinutes = minutes < 10 ? `0${minutes}` : minutes;

  return `${hours}:${zeroMinutes}`;
}

function getChatMessageClass() {
  return {
    'chat-message': true,
    "chat-message--error": message.isError,
    "chat-message--attachment" : message.attachment !== undefined,
    "chat-message--user" : message.isClient === true,
    "chat-message--minimal": message.time === ''
  }
}

const validContent = () => escapeMessageText(message.text);

function onFileNameClick() {
  isDownloadFile = true
  if (message.attachment.signature !== undefined && message.attachment.documentId !== undefined) {
    chat.downloadFileHistory(message.attachment.fileName, message.attachment.signature, message.attachment.documentId)
  } else if (message.attachment.fileSecureKey !== undefined) {
    const downloadPromise = chat.downloadFileSession(
      message.attachment.fileName,
      message.attachment.fileId,
      message.attachment.fileSecureKey,
      (progress) => {
        downloadedData = progress
      })

    downloadPromise.then(
      (response) => {
        isDownloadFile = false
      },
      (error) => {
        isDownloadFile = false
      }
    )
  }
}
function downloadFileByLink() {
  window.open(message.text);
}

onMount(() => {
  if (message.attachment !== undefined && message.attachment.promise !== undefined) {
    message.attachment.promise.then(
      (response) => {
        try {
          message.attachment.fileId = response.userData['file-id']
          if (bufferStatus === STATUS_MESSAGE_SENDING) bufferStatus = STATUS_MESSAGE_SEND
        } catch (e) {
        }
      },
      (error) => {
      }
    )
  }
  if (message.attachment !== undefined && message.attachment.previewImagePromise !== undefined) {
    message.attachment.previewImagePromise.then(
      (response) => {
        message.attachment.preview = response
    },
      (error) => {
      }
    )
  }
})
</script>

<style lang="scss" src="./style.scss" scoped></style>
