<div class="chat-message chat-message--notice">
  { message.text }
</div>


<script>
export let message;
</script>


<style lang="scss">
@import "extensions";

.chat-message {
  &--notice {
    @extend %body;
    margin-top: 17px;
    margin-bottom: 17px;
    text-align: center;
    display: block;
  }
}
</style>
