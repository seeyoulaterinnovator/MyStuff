<span
  class="wait-dots"
  class:wait-dots--animated={animate}
></span>

<script>
export let animate = false;
</script>

<style>
  @keyframes wait-animation {
    25% {
      content: "";
    }
    50% {
      content: ".";
    }
    75% {
      content: "..";
    }
    100% {
      content: "...";
    }
  }

  .wait-dots {
    box-sizing: border-box;
  }

  .wait-dots::after {
    content: '';
    animation: 1s infinite .3s;
    animation-fill-mode: forwards;
  }

  .wait-dots--animated::after {
    animation-name: wait-animation;
    animation-play-state: running;
  }
</style>
