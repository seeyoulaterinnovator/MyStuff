<script>
  import { onMount, createEventDispatcher } from "svelte";

  export let autoScroll = true
  export let count = 0
  let oldCount = count
  let oldTotalHeight = 0
  let bar, wrapper, scrollRatio, scrollContainer, scrollContent, scrollBar
  $: {
    if (autoScroll && count != oldCount) {
      oldCount = count;
      oldTotalHeight = scrollContent.scrollHeight
      scrollToBottom();
    }
  }

  const raf =
    window.requestAnimationFrame ||
    window.setImmediate ||
    function(c) {
      return setTimeout(c, 0);
    };

  function scrollToBottom() {
    setTimeout(() => {
      scrollContent.scrollTop =
        scrollContent.scrollHeight - scrollContent.clientHeight + 100;
    }, 100);
  }
  function dragDealer() {
    let lastPageY;
    scrollBar.addEventListener("mousedown", function(e) {
      lastPageY = e.pageY;
      scrollBar.classList.add("ss-grabbed");
      document.body.classList.add("ss-grabbed");

      document.addEventListener("mousemove", drag);
      document.addEventListener("mouseup", stop);

      return false;
    });

    function drag(e) {

      const delta = e.pageY - lastPageY;
      lastPageY = e.pageY;

      raf(function() {
        scrollContent.scrollTop += delta / scrollRatio;
      });
    }

    function stop() {
      scrollBar.classList.remove("ss-grabbed");
      document.body.classList.remove("ss-grabbed");
      document.removeEventListener("mousemove", drag);
      document.removeEventListener("mouseup", stop);
    }
  }
  function moveBar() {
    const totalHeight = scrollContent.scrollHeight,
      ownHeight = scrollContent.clientHeight;
    scrollRatio = ownHeight / totalHeight;

    const right = (scrollContainer.clientWidth - scrollBar.clientWidth) * -1;

    raf(function() {
      if (scrollRatio >= 1) {
        // scrollBar.classList.add("ss-hidden");
      } else {
        // scrollBar.classList.remove("ss-hidden");
        scrollBar.style.cssText =
          "height:" +
          Math.max(scrollRatio * 100, 10) +
          "%; top:" +
          (scrollContent.scrollTop / totalHeight) * 100 +
          "%;right:" +
          right +
          "px;";
      }
    });
  }
  onMount(() => {
    dragDealer();
    moveBar();

    window.addEventListener("resize", moveBar);
    scrollContent.addEventListener("scroll", moveBar);
    scrollContent.addEventListener("mouseenter", moveBar);
  window.scrollContent = scrollContent
    const css = window.getComputedStyle(scrollContent);
    if (css["height"] === "0px" && css["max-height"] !== "0px") {
      scrollContent.style.height = css["max-height"];
    }

  });
</script>

<style lang="scss">
  :global(.ss-wrapper) {
    overflow: hidden;
    width: 100%;
    height: 100%;
    position: relative;
    z-index: 1;
    float: left;
  }
  :global(.ss-container) {
    height: 100%;
    overflow: hidden;
  }

  :global(.ss-content) {
    height: 100%;
    margin-right: -18px;
    padding: 0 0 0 0;
    position: relative;
    overflow: auto;
    box-sizing: border-box;
  }

  :global(.ss-scroll) {
    position: relative;
    background: rgba(255, 221, 0, 0.8);
    width: 5px;
    border-radius: 4px;
    top: 0;
    z-index: 2;
    cursor: pointer;
    transition: opacity 0.25s linear;
  }

  :global(.ss-hidden) {
    display: none;
  }

  :global(.ss-container:hover .ss-scroll, .ss-container:active .ss-scroll) {
    opacity: 1;
  }

  :global(.ss-grabbed) {
    -o-user-select: none;
    -ms-user-select: none;
    -moz-user-select: none;
    -webkit-user-select: none;
    user-select: none;
  }
</style>

<div class="ss-container" style="height: 100%;" bind:this={scrollContainer}>
  <div class="ss-wrapper" bind:this={wrapper}>
    <div class="ss-content" bind:this={scrollContent}>
      <div class="cont">
        <slot />
      </div>
    </div>
  </div>
  <div class="ss-scroll" bind:this={scrollBar} />
</div>
