{#if show}
<div class="date-label">
  <div class="date-label__text">
    { getBeautyDate(date) }
  </div>
</div>
{/if}


<script>
import * as DATES from 'types/dates.js';

export let date = undefined;
export let prevDate = undefined;
let show = false;


/* === reactivity === */
$: {
  const d = new Date(date);
  const p = new Date(prevDate);

  const isMonthDifferent = p.getMonth() < d.getMonth();
  const isDayDifferent = p.getDate() < d.getDate()

  show = isDayDifferent || isMonthDifferent
}


/* === methods === */
function getBeautyDate(d) {
  let date = new Date(d);
  const monthName = DATES.monthNames[date.getMonth()];
  const dayName = DATES.dayNames[date.getDay()];
  const dayNumber = date.getDate();

  return `${dayName}, ${dayNumber} ${monthName}`;
}
</script>


<style lang="scss">
@import "extensions";

.date-label {
  padding: $padding-x4 0;
  text-align: center;

  &__text {
    background-color: rgba(0,0,0,.05);
    @extend %caption2;

    line-height: 24px;

    border-radius: 14px;
    padding: $padding-x1 $padding-x6;

    text-align: center;
    display: inline-block;
  }
}
</style>
