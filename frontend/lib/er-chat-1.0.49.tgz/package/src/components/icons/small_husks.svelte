<IconWrap content={svg} name={name} />

<script>
const name = 'small_husks';

import IconWrap from '../IconWrap.svelte';
import svg from 'icons/small_husks.svg';
</script>
