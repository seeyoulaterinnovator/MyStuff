<IconWrap content={svg} name={name} />

<script>
const name = 'send';

import IconWrap from 'components/IconWrap.svelte';
import svg from 'icons/send.svg';
</script>
