<IconWrap content={svg} name={name} />

<script>
const name = 'ok';

import IconWrap from 'components/IconWrap.svelte';
import svg from 'icons/ok.svg';
</script>
