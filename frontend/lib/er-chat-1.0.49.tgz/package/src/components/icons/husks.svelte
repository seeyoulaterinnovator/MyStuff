<IconWrap content={svg} name={name} />

<script>
const name = 'husks';

import IconWrap from '../IconWrap.svelte';
import svg from 'icons/husks.svg';
</script>
