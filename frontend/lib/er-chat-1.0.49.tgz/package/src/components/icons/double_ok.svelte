<IconWrap content={svg} name={name} />

<script>
const name = 'double_ok';

import IconWrap from 'components/IconWrap.svelte';
import svg from 'icons/double_ok.svg';
</script>
