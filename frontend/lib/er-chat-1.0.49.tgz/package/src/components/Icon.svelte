<span class="icon icon--{ name }">
  <svg
    viewBox="0 0 32 32"
    width={ `${width}px` }
    height={ height ? `${height}px` : `${width}px` }
  >
    <use xmlns:xlink='http://www.w3.org/1999/xlink'
      xlink:href={ `${iconUrl}#${name}` }
    />
  </svg>
</span>

<script>
export let name = '',
  width = 16,
  height = null;

const iconUrl = '/icons.svg';
</script>
