<div class="chat-input">
  <textarea
    class="chat-input__textarea"
    placeholder="Написать сообщение"
    bind:value={messageText}
    bind:this={textareaElement}
    on:keydown={onTextareaKeydown}
    rows="1"
  ></textarea>

  <div class="chat-input__actions">
    <button
      class="chat-input__action send-button"
      class:visible="{!isMessageEmpty(messageText)}"
      on:click|preventDefault="{sendMessage}"
    >
      <IconSend />
    </button>

    <label
      class="chat-input__action attachment"
      class:visible="{isMessageEmpty(messageText)}"
    >
      <input
        id="chat-file"
        type="file"
        class="attachment-field"
        multiple
        on:change="{attachFile}"
      />

      <IconHusks />
    </label>
  </div>
</div>

<script>
import autosize from 'autosize';

import IconHusks from 'components/icons/husks.svelte';
import IconSend from 'components/icons/send.svelte';

import { createEventDispatcher } from 'svelte';
import { onMount } from 'svelte';

let textareaElement;
let messageText = '';
const dispatch = createEventDispatcher();

function onTextareaKeydown(event) {
  if (event.code === 'Enter') {
    event.preventDefault();
    sendMessage(event);
  }
}

function attachFile() {
  const files = this.files;

  if (files.length !== 0) {
    dispatch('attachFile', {
      files
    })
  }
  this.value = ''
}

function isMessageEmpty(msg) {
  return msg.trim().length === 0
}

function sendMessage() {
  if (messageText !== '') {
    dispatch('message', {
      messageText
    })
    messageText = '';
    textareaElement.style.height = null
  }
}

onMount(() => {
  autosize(textareaElement);
})
</script>

<style lang="scss">
@import "vars";
@import "mixins/color";
@import "extensions";
@import "components";

.chat-input {
  @extend %content-h-padding;

  border-top: 1px solid map_get($colors, 'input-border');
  display: flex;
  flex-direction: row;

  .send-button {
    background-color: map_get($colors, send-button-active-bg);
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    justify-content: center;
    align-items: center;
    line-height: 40px;
    color: black;

    & > :global(span) {
      display: flex;
      justify-content: center;
    }
  }

  &__actions {
    display: flex;
    align-items: center;
    align-self: center;
    width: $padding-x8;
    height: $padding-x8;
    position: relative;

    & > * {
      position: absolute;
      transform: translate(-50%, -50%) scale(.8);
      left: 50%;
      top: 50%;
    }
  }

  &__textarea {
    @extend %body;
    background-color: transparent;
    display: block;
    border: none;
    resize: none;
    overflow: hidden;
    max-height: 200px;
    outline: none;
    box-sizing: border-box;
    margin: 0;
    width: 100%;

    padding: {
      top: $padding-x4;
      // left: $padding-x6;
      right: $padding-x6;
      bottom: $padding-x4;
    }

    &::placeholder {
      @include color-black(.5);
    }
  }

  &__action {
    display: block;
    cursor: pointer;
    border: none;
    background: none;
    padding: 0;
    width: 32px;
    height: 32px;
    margin: 0;
    outline: none;
    color: rgba($color: $color-black, $alpha: .6);
    opacity: 0;
    transition: all .2s ease-out;
    display: none;

    &.visible {
      opacity: 1;
      display: block;
      transform: translate(-50%, -50%) scale(1);
    }

    &:last-child {
      margin-right: 0;
    }
  }

  .attachment {
    &-field {
      display: none;
    }
  }
}
</style>
