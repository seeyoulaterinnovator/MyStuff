
<div class="chat-info">
  {#if scode === STATUS.AGENT_TYPING}
    <span>{agentName} печатает</span><WaitingDots animate={true} />
  {/if}

  {#if scode === STATUS.CUSTOM}
    <span>{message}</span>
  {/if}

  {#if scode === STATUS.SESSION_START}
    <span>Сессия начата</span>
  {/if}

  {#if scode === STATUS.SESSION_STOP}
    <span>Сессия остановлена</span>
  {/if}
</div>


<script>
import * as STATUS from 'types/status.js';
import WaitingDots from 'components/WaitingDots.svelte';


export let scode = STATUS.EMPTY;
export let agentName = '';
export let message = '';
</script>


<style lang="scss">
@import "vars";
@import "extensions";

.chat-info {
  @extend %caption2;
  background-color: transparent;
  padding: 0 $padding-x2;
}
</style>
