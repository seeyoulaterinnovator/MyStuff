<span class="icon icon--{ name }">
  {@html content }
</span>

<script>
export let content = '<!-- no icon -->';
export let name = 'empty';
</script>
