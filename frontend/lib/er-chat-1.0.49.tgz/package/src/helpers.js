
export const _$ = sel => document.querySelector(sel);
export const _$$ = sel => document.querySelectorAll(sel);

export function escapeMessageText(text) {
  if ((text !== undefined) && (text !== null)) {
    const removeTags = (data) => {
      const tmp = document.createElement("DIV");
      tmp.innerHTML = data;
      return tmp.textContent || tmp.innerText || "";
    }
    let textNode = removeTags(text);
    textNode = textNode.replace(/(\r\n|\n|\r|\u21b5|\xA)/gm, "<br />");
    return textNode
  }

  return text;
}


export function formatFileSize(bytes) {
  let fileSize = bytes;
  let unit = 'B'

  if (fileSize > 1024) {
    fileSize = Math.round((fileSize / 1024) * 100) / 100
    unit = 'KB'
    if (fileSize > 1024) {
      fileSize = Math.round((fileSize / 1024) * 100) / 100
      unit = 'MB'
    }
  }

  return `${fileSize}${unit}`
}


export function scrollToBottom(el) {
  setTimeout(
    () => {
      el.scrollTop = el.scrollHeight - el.clientHeight + 100
    },
    100
  )
}

export function getNextArrayItem(list, idx) {
  if (list.length >= idx-1) {
    return list[idx+1]
  }

  return null
}

export function saveBlobFile(blob, fileName) {
  if (window.navigator && window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveOrOpenBlob(blob, fileName)
  } else {
    var downloadLink = document.createElement('a')
    document.body.appendChild(downloadLink)
    downloadLink.style = 'display: none'
    const api = (window.URL || window.webkitURL)
    const fileURL = api.createObjectURL(blob)
    downloadLink.href = fileURL
    downloadLink.download = fileName
    downloadLink.click()
    downloadLink.remove()
    api.revokeObjectURL(fileURL)
  }
}
