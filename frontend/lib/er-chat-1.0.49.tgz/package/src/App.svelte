<div class="chat">
  <ScrollContent count={messageList.length}>
    <div class="chat__messages">
    {#each messageList as message,index}
      {#if message.type === 'notice'}
        <NoticeMessage {message} />
      {:else}
        <DateLabel
          date={message.utcTime}
          prevDate={messageList[index-1].utcTime}
        />

        <Message
          {message}
          showTime={
            !isMessagesEqual(message, getNextArrayItem(messageList, index))
          }
          showFrom={
            !isMessagesEqual(message, messageList[index-1])
          }
          bind:isAgentTyping={agentTyping}
          bind:chat={chat}
        />
      {/if}
    {/each}
    </div>
  </ScrollContent>
  {#if !isChatConnect }
    <div class="chat__welcome-message">Если у Вас есть вопросы, задайте их здесь.</div>
  {/if}
  <StatusInfo
    bind:scode={statusCode}
    bind:message={statusMessage}
    {agentName}
  />

  <InputField
    on:message={handleMessage}
    on:attachFile={sendFile}
  />
</div>


<script>
/* === Импорты === */
import { onMount } from 'svelte';

import { getNextArrayItem } from './helpers.js';
import * as STATUS from 'types/status.js';

import DateLabel from 'components/DateLabel.svelte';
import StatusInfo from 'components/StatusInfo.svelte';
import NoticeMessage from 'components/NoticeMessage.svelte';
import Message from 'components/Message/index.svelte';
import InputField from 'components/Input.svelte';
import ScrollContent from 'components/ScrollContent.svelte';

import Chat from './Chat.js';

/* === Переменнные === */
let statusCode = STATUS.EMPTY;
let statusMessage = '';
let agentName = 'Оператор'
let messageList = [];
let agentTyping = false
let chat = {}
let chatStarted = false
let uploadPercentage = 0
let isChatConnect = false
let onlineStatusHook = (...params) => {
  console.info('onlineStatusHook', params);
}
let operatorNameHook = () => {}
$: if (chat.hasOwnProperty('connect')) {
  isChatConnect = chat.connect
}

/* === Props === */
export let chatParameters = {};

/* === Методы === */
function isMessagesEqual (message, nextMessage) {
  return (nextMessage && message) &&
    message.type === nextMessage.type &&
    message.isClient === nextMessage.isClient
}


function sendFile (e) {
  const files = e.detail.files
  if (chat.connect === false) {
    chat.startChatSession(() => {
      chat.sendFiles(files)
    })
  } else {
    chat.sendFiles(files)
  }
}

function handleMessage (e) {
  const text = e.detail.messageText.trim();

  if (text) {
    chat.sendTextMessage(text)
  }
  return false
}

function updateFileUpload (index, percent) {
  messageList[index].attachment.percent = percent
}

function addMessage (e) {
  messageList = [...messageList, e]
  return messageList.length - 1
}

function agentTypingStart (e) {
  agentName = e
  statusCode = STATUS.AGENT_TYPING;
  onlineStatusHook(true);
  setMessagesReaded();
}

function setMessagesReaded () {
  messageList.map((message) => { message.isReaded = true })
}

function agentTypingStop () {
  statusCode = STATUS.EMPTY
}

function participantLeft () {
  onlineStatusHook(false);
}

function participantJoined (name) {
  operatorNameHook(name)
  onlineStatusHook(true)
}

function updateStatusMessage (message) {
  statusCode = STATUS.CUSTOM;
  statusMessage = message;
}


export function connect() {
  if(!chatStarted) {
    chatStarted = true
    chat.startChatSession(() => {
      console.info('chat session started')
    })
  }
}

onMount(() => {
  onlineStatusHook = chatParameters.onlineStatusHook || onlineStatusHook;
  operatorNameHook = chatParameters.operatorNameHook || operatorNameHook;

  let newChatParameters = Object.assign(
    chatParameters,
    {
      // addAttachmentSignature: this.addAttachmentSignature,
      updateStatus: updateStatusMessage,
      addMessage,
      updateFileUpload,
      agentTypingStart,
      agentTypingStop,
      participantLeft,
      participantJoined
    }
  );

  chat = new Chat(newChatParameters);
});
</script>


<style lang="scss" src="scss/themes/default.scss"></style>
