import CometD from 'cometd'
import TimeStampExtension from 'cometd/TimeStampExtension'
import cookies from 'js-cookie'
import { saveBlobFile } from './helpers'


const requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame ||
window.webkitRequestAnimationFrame || window.msRequestAnimationFrame

const cookieOptionsUnlimited = {}
cookieOptionsUnlimited.expires = 3600 * 24 * 365

const COOKIE__GENESYS_CHAT_ALIAS = 'genesysChatAlias'
const COOKIE__GENESYS_CHAT_ID = 'genesysChatId'
const COOKIE__GENESYS_CHAT_USER_ID = 'genesysChatUserId'
const COOKIE__GENESYS_CHAT_SECURE_KEY = 'genesysChatSecureKey'

const CHAT__CHANEL = '/service/chatV2/web_chat_b2b'

const MESSAGE_FROM_TYPE__AGENT = 'Agent'
const MESSAGE_FROM_TYPE__CLIENT = 'Client'
const MESSAGE_FROM_TYPE__EXTERNAL = 'External'

const MESSAGE_TYPE__PARTICIPANT_JOINED = 'ParticipantJoined'
const MESSAGE_TYPE__PARTICIPANT_LEFT = 'ParticipantLeft'
const MESSAGE_TYPE__MESSAGE = 'Message'
const MESSAGE_TYPE__FILE_UPLOADED = 'FileUploaded'
const MESSAGE_TYPE__PUSH_URL = 'PushUrl'
const MESSAGE_TYPE__SECRET_DATA = 'CustomNotice'
const MESSAGE_TYPE__FILE_DELETED = 'FileDeleted'
const MESSAGE_TYPE__TYPING_STARTED = 'TypingStarted'
const MESSAGE_TYPE__TYPING_STOPPED = 'TypingStopped'

const STATUS_MESSAGE_SENDING = 0
const STATUS_MESSAGE_SEND = 1
const STATUS_MESSAGE_READED = 2

const UPLOAD_FILE_MAX_SIZE_MB = 5
const uploadFileAvailableFormat = [
  '.avi',
  '.doc',
  '.docx',
  '.flv',
  '.gif',
  '.html',
  '.jpg',
  '.jpeg',
  '.mkv',
  '.mov',
  '.mp4',
  '.odp',
  '.ods',
  '.odt',
  '.pdf',
  '.png',
  '.ppt',
  '.pptx',
  '.rtf',
  '.txt',
  '.wma',
  '.xls',
  '.xlsx'
]
const uploadFileAvailableFormatForImage = [
  '.jpg',
  '.jpeg',
  '.png'
]

export default class Chat {
  constructor (parameters) {
    this.connect = false
    this.connecting = false
    this.isUploadingFile = false
    this.isRecovery = false
    this.infoUploadedFiles = {
      fileIds: [],
      documentIds: []
    }

    this.nickname = parameters.nickname || 'Неизвестный пользователь'
    this.subject = parameters.subject || '';
    this.city = parameters.city || undefined;
    this.userData = parameters.userData || undefined
    this.chatSession = this.isExistChatSession(this.getChatSessionFromCookie()) ? this.getChatSessionFromCookie() : false

    this.genesysDomain = parameters.isProd ? `https://genesys.domru.ru` : `https://genesys-test.domru.ru`

    this.GMS__COMETD__URL = `${this.genesysDomain}/web_chat/genesys/cometd`
    this.GMS__COMETD__FILE__URL = `${this.genesysDomain}/web_chat/genesys/2/chat-ntf`
    this.HISTORY__URL = `${this.genesysDomain}/ucs-history/v1/interactions`

    this.callBacks = {
      updateStatus: parameters.updateStatus,
      updateFileUpload: parameters.updateFileUpload,
      participantLeft: parameters.participantLeft,
      participantJoined: parameters.participantJoined,
      // addAttachmentSignature: parameters.addAttachmentSignature,  
      addMessage: parameters.addMessage,
      agentTypingStart: parameters.agentTypingStart,
      agentTypingStop: parameters.agentTypingStop
    }

    this.queueDelayedSending = []
    this._delayedSending()
  }


  startChatSession() {
    return new Promise((resolve, reject) => {
      if (!this.connect && !this.connecting) {
        this.connecting = true
        this._connectToCometdServer()
          .then(response => {
            if (this.chatSession) {
              this._recoveryChat()
                .then(response => {
                  resolve()
                })
                .catch(err => {
                  console.error(err)
                  reject(err)
                })
            } else {
              this._requestChat()
                .then(response => {
                  resolve()
                })
                .catch(err => {
                  console.error(err)
                  reject(err)
                })
            }
          })
          .catch(err => {
            console.error(err)
            reject(err)
          })
      } else if (this.connect) {
        resolve()
      }
    })
  }

  _connectToCometdServer () {
    this.callBacks.updateStatus('Ожидание подключения...')
    this.cometd = new CometD.CometD()
    this.cometd.registerExtension('timestamp', new TimeStampExtension())
    this.cometd.configure({
      url: this.GMS__COMETD__URL,
    })
    const handshakePromise = new Promise((resolve, reject) => {
      this.subscription1 = this.cometd.addListener('/meta/handshake', (handshake) => {
        const handshakeResult = this._handleHandshake(handshake, resolve)
        if (handshakeResult) {
          resolve(handshake);
        } else {
          this.callBacks.updateStatus('Ошибка подключения')
          reject('ошибка установки соединения')
        }
      })
    })
    this.cometd.handshake()
    return handshakePromise
  }

  _handleHandshake (handshake, resolve) {
    if (handshake.successful === true) {
      this.subscription2 = this.cometd.addListener(CHAT__CHANEL, (m) => {
        this._handleChatEvent(m)
      })
      return true
    }
    return false
  }

  _requestChat () {
    let userData = {
      'clientType': 'b2b',
      'citydomain': this.city
    }
    if (this.userData) {
      userData = {
        ...userData,
        ...this.userData
      }      
    } else {
      userData = {
        'gaCid': cookies.get('_ga_cid') || cookies.get('_ga').substr(6),
        ...userData,
      }
    }
    const requestChatData = {
      'operation': 'requestChat',
      'nickname': this.nickname,
      'subject': this.subject,
      userData
    }
    return new Promise((resolve, reject) => {
      this.cometd.publish(CHAT__CHANEL, requestChatData, (e) => {
        if (e.successful == false) {
          console.error(e)
          reject('ошибка создания сессии')
        } else {
          resolve('новая сессия получена успешно')
        }
      })
    })
  }

  _recoveryChat() {
    const requestNotificationsData = {
      'operation': 'requestNotifications',
      'alias': this.chatSession.alias,
      'chatId': this.chatSession.chatId,
      'userId': this.chatSession.userId,
      'secureKey': this.chatSession.secureKey,
      'transcriptPosition': '1'
    }
    return new Promise((resolve, reject) => {
      this.cometd.publish(CHAT__CHANEL, requestNotificationsData, (e) => {
        if (e.successful == false) {
          console.warn(e)
          reject('ошибка восстановления сессии')
        } else {
          this.isRecovery = true
          resolve('сессия восстановлена успешно')
        }
      })
    })
  }

  isExistChatSession (_chatSession) {
    return (_chatSession.alias !== undefined) &&
    (_chatSession.chatId !== undefined) &&
    (_chatSession.userId !== undefined) &&
    (_chatSession.secureKey !== undefined)
  }

  _handleChatEvent (m) {
    if ((m !== undefined) && (m !== null)) {
      if (m.data.statusCode === 0) {
        const {messages} = m.data
        for (let mesInd = 0; mesInd < messages.length; mesInd++) {
          const message = messages[mesInd]
          if (message.type === MESSAGE_TYPE__PARTICIPANT_JOINED &&
            message.from.type === MESSAGE_FROM_TYPE__CLIENT &&
            !this.chatSession
          ) {
            this.chatSession = {
              alias: m.data.alias,
              chatId: m.data.chatId,
              userId: m.data.userId,
              secureKey: m.data.secureKey
            }
            this.putChatSessionToCookie(this.chatSession)
          }

          if (this.chatSession) {
            this.connect = true
            this.connecting = false
            this.callBacks.updateStatus('')
            this.messageFromServer(message)
          }
        }
      } else if (m.data.statusCode === 2) {
        const isNeedReconnect = this.connecting
        if (m.data.chatEnded === true) {
          this.isRecovery = false
          this.chatDisconnect()
        }
        if (isNeedReconnect) {
          this.connecting = false
          this.startChatSession()
        }
      } else {
        this.chatDisconnect()
        this.startChatSession()
      }
    }
  }

  chatDisconnect () {
    try {
      if (this.chatSession) {
        const disconnectData = {
          'operation': 'disconnect',
          'alias': this.chatSession.alias,
          'chatId': this.chatSession.chatId,
          'userId': this.chatSession.userId,
          'secureKey': this.chatSession.secureKey
        }
        this.cometd.publish(CHAT__CHANEL, disconnectData)
        this.clearChatSessionInCookie()
        this.cometd.removeListener(this.subscription2)
        this.cometd.removeListener(this.subscription1)
        this.cometd.disconnect()
        this.connect = false
        this.connecting = false
        this.chatSession = false
        this.callBacks.updateStatus('Сессия завершена')
      }
    } catch (e) {
      this._handleError({
        message: 'Ошибка окончании сессии чата'
      })
    }
  }

  messageFromServer (message) {
    const { nickname } = message.from
    switch (message.type) {
      case MESSAGE_TYPE__PARTICIPANT_JOINED:
        if (message.from.type !== MESSAGE_FROM_TYPE__EXTERNAL) {
          this.callBacks.addMessage({
            isClient: message.from.type === MESSAGE_FROM_TYPE__CLIENT,
            utcTime: message.utcTime,
            text: (message.from.type === MESSAGE_FROM_TYPE__CLIENT)
              ? 'Вы подключились к чату'
              : `${message.from.nickname} подключился к чату`,
            type: 'notice'
          })
          if (message.from.type !== MESSAGE_FROM_TYPE__CLIENT) this.callBacks.participantJoined(message.from.nickname)
        }
        break
      case MESSAGE_TYPE__PARTICIPANT_LEFT:
        if (message.from.type !== MESSAGE_FROM_TYPE__EXTERNAL) {
          if (MESSAGE_FROM_TYPE__CLIENT === message.from.type) {
            this.callBacks.addMessage({
              isClient: message.from.type === MESSAGE_FROM_TYPE__CLIENT,
              utcTime: message.utcTime,
              text: 'Вы вышли из чата',
              type: 'notice'
            })
          } else {
            this.callBacks.addMessage({
              isClient: message.from.type === MESSAGE_FROM_TYPE__CLIENT,
              utcTime: message.utcTime,
              text: `${message.from.nickname} вышел из чата`,
              type: 'notice'
            })
          }
        }

        this.callBacks.participantLeft()
        if (message.from.type === MESSAGE_FROM_TYPE__CLIENT) {
          this.chatDisconnect()
        }
        break
      case MESSAGE_TYPE__TYPING_STARTED:
        if (message.from.type === MESSAGE_FROM_TYPE__AGENT) {
          this.callBacks.agentTypingStart(nickname)
        }
        break
      case MESSAGE_TYPE__TYPING_STOPPED:
        if (message.from.type === MESSAGE_FROM_TYPE__AGENT) {
          this.callBacks.agentTypingStop(nickname)
        }
        break
      case MESSAGE_TYPE__MESSAGE:
        this.addMessage(message, message.from.type !== MESSAGE_FROM_TYPE__AGENT)
        break
      case MESSAGE_TYPE__SECRET_DATA:
        if (message.from.type === MESSAGE_FROM_TYPE__AGENT) {
          this.addMessage(message, message.from.type !== MESSAGE_FROM_TYPE__AGENT)
        }

        break
      case MESSAGE_TYPE__FILE_UPLOADED:
        this.infoUploadedFiles.fileIds.push(message.userData['file-id'])
        this.infoUploadedFiles.documentIds.push(message.userData['file-document-id'])

        if (message.from.type === MESSAGE_FROM_TYPE__CLIENT && this.isUploadingFile === true) return

        this.callBacks.addMessage({
          from: message.from.nickname,
          isClient: message.from.type === MESSAGE_FROM_TYPE__CLIENT,
          utcTime: message.utcTime,
          type: 'attachment',
          attachment: {
            fileSecureKey: this.getChatSessionFromCookie().secureKey,
            fileName: message.userData['file-name'],
            fileSize: message.userData['file-size'],
            fileDocumentId: message.userData['file-document-id'],
            fileId: message.userData['file-id']
          }
        })
        break
      case MESSAGE_TYPE__PUSH_URL:
        this.callBacks.addMessage({
          from: message.from.nickname,
          isClient: message.from.type === MESSAGE_FROM_TYPE__CLIENT,
          utcTime: message.utcTime,
          type: 'PushUrl',
          text: message.text
        })
        break
      case MESSAGE_TYPE__FILE_DELETED:
        break
    }
  }

  _isInArray (element, arr) {
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] === element) return i
    }
    return -1
  }

  getUserInfoById (userId, users) {
    for (let i = 0; i < users.length; i++) {
      if (users[i].id === userId) {
        return users[i]
      }
    }
    return {}
  }

  _ajax (url) {
    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest()
      xhr.open('GET', url)
      xhr.onload = function () {
        if (xhr.status === 200) {
          resolve(JSON.parse(xhr.response))
        } else {
          reject(new Error('Ошибка запроса'))
        }
      }

      xhr.onerror = function (e) {
        reject(e)
      }

      xhr.send()
    })
  }

  setNickName (value) {
    this.nickname = value
  }

  async getMessagesFromPage (page) {
    try {
      let url = `${this.HISTORY__URL}?mediaChannel=Web_chat`
      Object.keys(this.userData).forEach((key) => {
        url += `&${key}=${this.userData[key]}`
      })

      url += `&page=${page}&pageSize=10`
      const response = await this._ajax(url)

      const { interactions } = response
      const history = []

      for (let i = 0; i < interactions.length; i++) {
        if (history.length >= 15) {
          break
        }

        const interaction = interactions[i]
        let isCan = (this.isRecovery === true && interaction.status === 'Stopped')
        if (this.isRecovery === false) isCan = true

        if (isCan) {
          const interactionInfo = await this._getInterationInfo(interaction.id, interaction.signature)
          interactionInfo.interactionInfo.chat.messages.reverse().forEach((m) => {
            const sender = this.getUserInfoById(m.senderId, interactionInfo.interactionInfo.users)
            const messageObj = {
              status: STATUS_MESSAGE_READED,
              from: sender.nickname,
              utcTime: m.date * 1000,
              isClient: sender.role === 'CLIENT'
            }

            if (m.text !== undefined) {
              messageObj.type = 'message'
              messageObj.text = m.text
            }

            if (m.attachments !== undefined) {
              const attachment = m.attachments[0]
              messageObj.type = 'attachment'
              messageObj.attachment = {
                fileName: attachment.name,
                fileSize: attachment.size,
                signature: attachment.signature,
                documentId: attachment.documentId
              }
            }

            history.push(messageObj)
          })
        }
      }
      return history.reverse()
    } catch (e) {
      return []
    }
  }

  async _getInterationInfo (id, signature) {
    const url = `${this.HISTORY__URL}/${id}?signature=${signature}`
    const response = await this._ajax(url)
    return response
  }

  async _updateUploadedFilesInSession () {
    let url = `${this.HISTORY__URL}?mediaChannel=Web_chat`
    Object.keys(this.userData).forEach((key) => {
      url += `&${key}=${this.userData[key]}`
    })

    url += '&page=1&pageSize=1'
    const response = await this._ajax(url)

    if (response.interactions.length > 0) {
      const intId = response.interactions[0].id
      const intSig = response.interactions[0].signature
      if (intId !== undefined && intSig !== undefined) {
        try {
          const interactionInfo = await this._getInterationInfo(intId, intSig)
          interactionInfo.interactionInfo.chat.messages.forEach((message) => {
            if (message.attachments !== undefined) {
              for (let i = 0; i < message.attachments.length; i++) {
                const attachment = message.attachments[i]
                const idInArr = this._isInArray(
                  attachment.documentId,
                  this.infoUploadedFiles.documentIds
                )
                if (idInArr !== -1) {
                  this.callBacks.addAttachmentSignature(
                    this.infoUploadedFiles.fileIds[idInArr],
                    attachment.documentId,
                    attachment.signature
                  )
                  delete this.infoUploadedFiles.documentIds[idInArr]
                  delete this.infoUploadedFiles.fileIds[idInArr]
                }
              }
            }
          })

          this.infoUploadedFiles = {
            fileIds: [],
            documentIds: []
          }
        } catch (e) {
          this._handleError({
            message: 'Ошибка получения интеракции'
          })
        }
      } else {
        this._handleError({
          message: 'Ошибка получения последней интеракции'
        })
      }
    }
  }

  addMessage (m, isClient) {
    const messageObj = {
      from: m.from.nickname,
      utcTime: m.utcTime,
      isClient: isClient,
      text: m.text,
      type: 'message'
    }

    this.callBacks.addMessage(messageObj)
  }

  _sleep (ms = 1000) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  _delayedSending () {
    if (this.chatSession) {
      const callback = this.queueDelayedSending.shift();
      if(callback){
        callback(this.chatSession)
      }
    }
    this._sleep().then(() => {
      this._delayedSending()
    })
  }

  sendTextMessage (message) {
    this.startChatSession()
      .then(() => {
        const _sendMessage = (chatSession) => {
          const messageData = {
            'operation': 'send',
            'message': message,
            'alias': chatSession.alias,
            'chatId': chatSession.chatId,
            'userId': chatSession.userId,
            'secureKey': chatSession.secureKey
          }
          this.cometd.publish(CHAT__CHANEL, messageData, (e) => {
          })
        }
          if (this.chatSession && this.connect) {
            _sendMessage(this.chatSession)
          } else {
            this.queueDelayedSending.push(_sendMessage)
          }
      })
      .catch(err => {
        console.error(err)
      })
  }

  _handleError (obj) {
    this.callBacks.updateStatus('Ошибка подключения')
    console.error(obj.message)
  }

  putChatSessionToCookie (_chatSession) {
    cookies.set(
      COOKIE__GENESYS_CHAT_ALIAS,
      _chatSession.alias,
      cookieOptionsUnlimited
    )
    cookies.set(
      COOKIE__GENESYS_CHAT_ID,
      _chatSession.chatId,
      cookieOptionsUnlimited
    )
    cookies.set(
      COOKIE__GENESYS_CHAT_USER_ID,
      _chatSession.userId,
      cookieOptionsUnlimited
    )
    cookies.set(
      COOKIE__GENESYS_CHAT_SECURE_KEY,
      _chatSession.secureKey,
      cookieOptionsUnlimited
    )
  }

  getChatSessionFromCookie () {
    const _chatSession = {}
    _chatSession.alias = cookies.get(COOKIE__GENESYS_CHAT_ALIAS)
    _chatSession.chatId = cookies.get(COOKIE__GENESYS_CHAT_ID)
    _chatSession.userId = cookies.get(COOKIE__GENESYS_CHAT_USER_ID)
    _chatSession.secureKey = cookies.get(COOKIE__GENESYS_CHAT_SECURE_KEY)
    return _chatSession
  }

  clearChatSessionInCookie () {
    cookies.remove(COOKIE__GENESYS_CHAT_ALIAS)
    cookies.remove(COOKIE__GENESYS_CHAT_ID)
    cookies.remove(COOKIE__GENESYS_CHAT_USER_ID)
    cookies.remove(COOKIE__GENESYS_CHAT_SECURE_KEY)
  }

  downloadFileSession (fileName, fileId, secureKey, downloadProgress) {
    if (fileName === undefined || fileId === undefined || secureKey === undefined) return
    const d = new Date()
    const formData = new FormData()
    formData.append('operation', 'fileDownload')
    formData.append('secureKey', secureKey)
    formData.append('fileId', fileId)
    formData.append('Key', d.getTime())
    const self = this
    async function download() {
      let promise = new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.onprogress = function(event) {
          downloadProgress(event.loaded)
        }

        xhr.open('POST', self.GMS__COMETD__FILE__URL)

        xhr.onload = function () {
          if (xhr.status === 200) {
            const contentType = xhr.getResponseHeader('Content-Type')
            const data = xhr.response
            const file = new Blob([data], {type: contentType})
            resolve(true)
            saveBlobFile(file, fileName);
          } else {
            reject('error')
          }
        }

        xhr.responseType = 'arraybuffer'
        xhr.send(formData)
      });

      let result = await promise;
      return result
    }
    return download()
  }

  downloadFileHistory (fileName, signature, documentId) {
    const url = `${this.HISTORY__URL}/document/${documentId}?signature=${signature}`

    const xhr = new XMLHttpRequest()
    xhr.onprogress = function(event) {
      // console.log( 'downloadFileHistory ' + event.loaded + ' байт из ' + event.total )
    }
    xhr.open('GET', url)
    xhr.onload = function () {
      if (xhr.status === 200) {
        const contentType = xhr.getResponseHeader('Content-Type')
        const data = xhr.response
        const file = new Blob([data], {type: contentType})

        saveBlobFile(file, fileName);
      }
    }

    xhr.responseType = 'arraybuffer'
    xhr.send()
  }

  _getNameAndExtFile (fileName) {
    const arr = fileName.split('.')
    return arr[arr.length - 1].toLowerCase()
  }

  _isValidFormat (ext) {
    for (let i = 0; i < uploadFileAvailableFormat.length; i++) {
      if (`.${ext}` === uploadFileAvailableFormat[i]) return true
    }
    return false
  }
  _isImage (ext) {
    for (let i = 0; i < uploadFileAvailableFormatForImage.length; i++) {
      if (`.${ext}` === uploadFileAvailableFormatForImage[i]) return true
    }
    return false
  }

  sendFiles (files_) {
    const files = files_
    if (files.length > 0) {
      for (let i = 0; i < files.length; i++) {
        const file = files[i]
        if (file !== undefined) {
          requestAnimationFrame(() => {
            this._sendFile(file)
          })
        }
      }
    }
  }

  _getSendFilePromise (file, index) {
    const self = this
    return new Promise((resolve, reject) => {
      const chatSession = this.getChatSessionFromCookie()
      if (this.isExistChatSession(chatSession)) {
        const d = new Date()
        const formData = new FormData()
        formData.append('operation', 'fileUpload')
        formData.append('secureKey', chatSession.secureKey)
        formData.append('file', file, file.name)
        formData.append('Key', d.getTime())

        const xhr = new XMLHttpRequest()
        xhr.open('POST', `${this.GMS__COMETD__FILE__URL}?t=${d.getTime()}`)
        xhr.onreadystatechange = function () {
          if (xhr.readyState === 4) {
            if (xhr.status !== 200) {
              let isFileLimitError = false
              const data = JSON.parse(xhr.responseText)
              if (data.errors !== undefined) {
                if (data.errors.length > 0) {
                  if (data.errors[0].code === 201) {
                    isFileLimitError = true
                  }
                }
              }
              if (isFileLimitError) {
                reject(new Error('Максимальное количество файлов<br>в одном диалоге -' + data.errors[0].advice))
              }
            } else {
              const data = JSON.parse(xhr.responseText)
              resolve(data)
            }
          }
        }

        xhr.upload.onprogress = function (event) {
          self.callBacks.updateFileUpload(index, Math.round(event.loaded / event.total * 100))
        }
        xhr.send(formData)
      } else {
        reject(new Error('Ошибка отправки файла'))
      }
    })
  }

  _sendFile (file) {
    this.isUploadingFile = true
    let error = ''
    if (file.size > UPLOAD_FILE_MAX_SIZE_MB * 1024 * 1024) {
      error = 'Файл слишком большой'
    }
    const ext = this._getNameAndExtFile(file.name)
    const self = this
    async function getPreview() {
      const reader = new FileReader()
      let promise = new Promise((resolve, reject) => {
        if (self._isImage(ext)) {
          reader.onload = function (e) {
            resolve(e.target.result)
          }
          reader.readAsDataURL(file)
        } else {
          resolve(undefined)
        }
      });

      let result = await promise;
      return result
    }
    const previewImagePromise = getPreview()

    if (!this._isValidFormat(ext)) {
      error = `Доступные форматы: ${uploadFileAvailableFormat.join(', ')}`
    }
    if (error === '') {
      const message = {
        isClient: true,
        status: STATUS_MESSAGE_SEND,
        utcTime: new Date().getTime(),
        type: 'attachment',
        attachment: {
          fileSecureKey: this.getChatSessionFromCookie().secureKey,
          fileName: file.name,
          fileSize: file.size,
          percent: null,
          previewImagePromise
        }
      }
      const index = this.callBacks.addMessage(message)
      const promise = this._getSendFilePromise(file, index)
      message.attachment.promise = promise
    } else {
      this.callBacks.addMessage({
        isClient: true,
        status: STATUS_MESSAGE_SENDING,
        utcTime: new Date().getTime(),
        type: 'attachment',
        attachment: {
          fileSecureKey: this.getChatSessionFromCookie().secureKey,
          fileName: file.name,
          fileSize: file.size,
          error
        }
      })
    }
  }
}
