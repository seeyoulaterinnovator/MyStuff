# ErChat

**ErChat** -- виджет чата в виде js-скрипта, который можно подключить к странице.


## Подключение виджета

### Вариант №1 — как скрипт на странице

В секции `<head>` подключаем скрипт `er-chat.browser.js` из папки `dist`

```html
<!DOCTYPE html>
<html>
  <head>
    <script src="/dist/er-chat.browser.js"></script>
    <script>
    // после загрузки страницы
    window.onload = () => {
      // задаём параметры чата
      const theChat = new ErChat({
        nickname: 'Имя пользователя',
        subject: 'Тема чата',
        city: 'Город'
      });

      // отрисовываем чат в элементе #my-chat
      theChat.attach(document.querySelector('#my-chat'))
      // начинаем сессию
      theChat.connect()
    }
    </script>
  </head>

  <body>
    <div id="my-chat">
  </body>
</html>
```

### Вариант №2 — импорт чата в коде

1. установить чат через `npm` из репозитория

  `npm i --save git+ssh://git@gitlab.ertelecom.ru:10022/Components/chat.git#dev`

2. импортировать **esm-версию** `ErChat`

  `import ErChat from 'er-chat/dist/er-chat.esm'`

3. создать экземпляр класса `ErChat`

  ```javascript
    const theChat = new ErChat({
      nickname: 'Имя пользователя',
      subject: 'Тема чата',
      city: 'Город'
    });

  ```
4. присоединить чат к DOM-элементу

  ```javascript
    theChat.attach(document.querySelector('#my-chat'))
  ```

5. начать сессию

  ```javascript
    theChat.connect()
  ```
