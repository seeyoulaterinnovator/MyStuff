import svelte from 'rollup-plugin-svelte';
import resolve from 'rollup-plugin-node-resolve';
import commonjs from 'rollup-plugin-commonjs';
import livereload from 'rollup-plugin-livereload';
import { terser } from 'rollup-plugin-terser';
import rollup_start_dev from './rollup_start_dev';
// import collectSass from 'rollup-plugin-collect-sass';
// import postcss from 'rollup-plugin-postcss';
import svg from 'rollup-plugin-svg';
import alias from 'rollup-plugin-alias';

import { scss } from 'svelte-preprocess'

import babel from 'rollup-plugin-babel';


const production = !process.env.ROLLUP_WATCH;


const plugins = [
  svelte({
    // enable run-time checks when not in production
    dev: !production,
    preprocess: [
      scss({
        includePaths: ['src/scss/'],
      })
    ]
  }),
  // postcss({
  //   extract: true
  // }),
  /*
    collectSass собирает стили, импортируемые в javascript
    используется для компиляции отдельного файла темы оформления
  */
  // collectSass({}),

  /*
    svg собирает иконки, импортируемые в javascript
  */
  svg(),
  alias({
    resolve: ['.js'],
    entries: {
      icons: 'src/assets/icons',
      components: 'src/components',
      types: 'src/types'
    }
  }),

  // If you have external dependencies installed from
  // npm, you'll most likely need these plugins. In
  // some cases you'll need additional configuration —
  // consult the documentation for details:
  // https://github.com/rollup/rollup-plugin-commonjs
  resolve({
    browser: true,
    dedupe: importee => importee === 'svelte' || importee.startsWith('svelte/')
  }),
  commonjs(),

  babel({
    extensions: [ '.js', '.mjs', '.html', '.svelte' ],
    runtimeHelpers: true,
    exclude: [ 'node_modules/@babel/**', 'node_modules/core-js/**' ],
    presets: [
      [
        '@babel/preset-env',
        {
          targets: '> 0.25%, not dead',
          useBuiltIns: 'usage',
          corejs: 3
        }
      ]
    ],
    plugins: [
      '@babel/plugin-syntax-dynamic-import',
      [
        '@babel/plugin-transform-runtime',
        {
          useESModules: true
        }
      ]
    ]
  }),

    // In dev mode, call `npm run start:dev` once
  // the bundle has been generated
  !production && rollup_start_dev,

  // Watch the `public` directory and refresh the
  // browser on changes when not in production
  !production && livereload('public'),

  // If we're building for production (npm run build
  // instead of npm run dev), minify
  production && terser()
];

export default [
  {
    input: 'src/main.js',
    output: {
      format: 'esm',
      name: 'ErChat',
      file: production ? 'dist/er-chat.esm.js' : 'public/bundle.esm.js'
    },
    plugins,
    watch: {
      clearScreen: false
    }
  },
  {
    input: 'src/main.js',
    output: {
      sourcemap: !production,
      format: 'iife',
      name: 'ErChat',
      file: production ? 'dist/er-chat.browser.js' : 'public/bundle.js'
    },
    plugins,
    watch: {
      clearScreen: false
    }
  },
];
